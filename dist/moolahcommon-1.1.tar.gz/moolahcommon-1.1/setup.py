#!/usr/bin/env python

from distutils.core import setup
setup(name='moolahcommon',
      version='1.1',
      py_modules=['exch_binance','portfolio','signal','config','exch_bitfinex','mockExchange','position','util','context','exchange','order'],
      )
