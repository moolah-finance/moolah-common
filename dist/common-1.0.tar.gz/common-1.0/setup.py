#!/usr/bin/env python

from distutils.core import setup
setup(name='common',
      version='1.0',
      py_modules=['exch_binance','portfolio','signal','config','exch_bitfinex','mockExchange','position','util','context','exchange','order'],
      )
